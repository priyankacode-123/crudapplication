# CRUD WITH FLASK

This is a simple CRUD application package while using flask framework. 